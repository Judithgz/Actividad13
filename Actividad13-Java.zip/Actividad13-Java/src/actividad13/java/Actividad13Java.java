package actividad13.java;
import java.util.*;


public class Actividad13Java {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner leer = new Scanner(System.in);
        
        List nombres = new LinkedList<>();
        
        String name;
        
        for(int i = 0; i < 6; i++){
            
            System.out.print("Nombre " + i + ": ");
            name = leer.next();
            
            nombres.add(name);
        }
        
        System.out.println(" ");
        Collections.sort(nombres);
        
        for(Object thisList : nombres){
            
            System.out.println(thisList);
        }
        
    }
    
}
